using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using _4th_Exam.Models;
using Npgsql;

namespace _4th_Exam.Repository
{
    public class LoginRepository : ILoginRepository
    {
        public NpgsqlConnection _conn;
        public LoginRepository(NpgsqlConnection conn)
        {
            _conn = conn;
        }
        public bool Login(tbllogin login)
{
    var isAuthenticate = false;
    _conn.Open();
    using var command = new NpgsqlCommand("SELECT c_role FROM t_login WHERE c_email = @c_email AND c_password = @c_password", _conn);
    command.CommandType = CommandType.Text;
    command.Parameters.AddWithValue("@c_email", login.c_email);
    command.Parameters.AddWithValue("@c_password", login.c_password);
    var result = command.ExecuteScalar();
    if (result != null)
    {
        // If a record is found, set isAuthenticate to true
        isAuthenticate = true;
        // You may want to retrieve the role here
        login.c_role = result.ToString();
    }
    _conn.Close();
    return isAuthenticate;
}

    }
}