using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using _4th_Exam.Models;

namespace _4th_Exam.Repository
{
    public interface ILoginRepository
    {
        public bool Login(tbllogin login);
    }
}