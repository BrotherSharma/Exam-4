using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using _4th_Exam.Models;
using Npgsql;

namespace _4th_Exam.Repository
{
    public class UserRepository : IUserRepository
    {
        public NpgsqlConnection _conn;
        public UserRepository(NpgsqlConnection conn)
        {
            _conn = conn;
        }
        public tbltrip GetPrice(string emp)
        {
            var tbltrip = new tbltrip();
            _conn.Open();
            using var command = new NpgsqlCommand("SELECT * FROM t_trip WHERE c_tripname = @c_tripname",_conn);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@c_tripname",emp);
            using var reader = command.ExecuteReader();
            while(reader.Read())
            {
                
                
                    tbltrip.c_tripname = reader["c_tripname"].ToString();
                    tbltrip.c_price =Convert.ToInt32(reader["c_price"]);
                    tbltrip.c_stock =Convert.ToInt32(reader["c_stock"]);
                    tbltrip.c_avail =Convert.ToInt32(reader["c_avail"]);
                    tbltrip.c_id =Convert.ToInt32(reader["c_id"]);
                
            }
            _conn.Close();
            return tbltrip;
        }
        public void Book(tbltrip customer)
        {
            _conn.Open();
            using NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO t_history VALUES (default, @c_name, @c_price, @c_qty, @c_total,'Scheduled')", _conn);
            cmd.Parameters.AddWithValue("@c_name", customer.c_tripname);
            cmd.Parameters.AddWithValue("@c_price", customer.c_price);
            cmd.Parameters.AddWithValue("@c_qty", customer.c_quantity);
            cmd.Parameters.AddWithValue("@c_total", customer.c_total);
            cmd.Parameters.AddWithValue("@c_total", customer.c_total);
            cmd.ExecuteNonQuery();
            _conn.Close();
        }
        public List<tbltrip> GetAll()
        {
            List<tbltrip> trips = new List<tbltrip>();
            _conn.Open();
            using NpgsqlCommand cmd = new NpgsqlCommand("SELECT * FROM t_history", _conn);
            using(var dr = cmd.ExecuteReader())
            {
                while(dr.Read())
                {
                    var trip = new tbltrip()
                    {
                        c_id = Convert.ToInt32(dr["c_id"]),
                        c_tripname = dr["c_tripname"].ToString(),
                        c_price = Convert.ToInt32(dr["c_price"]),
                        c_quantity = Convert.ToInt32(dr["c_quantity"]),
                        c_total = Convert.ToInt32(dr["c_total"]),
                        c_status = dr["c_status"].ToString(),
                        
                        
                    };
                    trips.Add(trip);
                }
            }
            _conn.Close();
            return trips;
        }
        public void Remove(int id)
        {
            _conn.Open();
            using NpgsqlCommand cmd = new NpgsqlCommand("UPDATE t_history SET c_status='Canceled' WHERE c_id = @id", _conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            _conn.Close();
        }
        public void Update(tbltrip customer)
        {
            _conn.Open();
            using NpgsqlCommand cmd = new NpgsqlCommand("UPDATE t_trip SET c_stock = c_avail - @c_quantity WHERE c_tripname = @c_tripname",_conn);
            cmd.Parameters.AddWithValue("@c_tripname", customer.c_tripname);
            cmd.Parameters.AddWithValue("@c_quantity", customer.c_quantity);
            cmd.ExecuteNonQuery();
            _conn.Close();
        }
    }
}