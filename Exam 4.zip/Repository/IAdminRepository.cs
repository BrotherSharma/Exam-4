using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using _4th_Exam.Models;

namespace _4th_Exam.Repository
{
    public interface IAdminRepository
    {
        public List<tbltrip> GetAll();
        public void Insert(tbltrip trip);
        public tbltrip GetOne(int id);
        public void Update(tbltrip trip);
        public void Delete(int id);
    }
}