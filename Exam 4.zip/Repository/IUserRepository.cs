using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using _4th_Exam.Models;

namespace _4th_Exam.Repository
{
    public interface IUserRepository
    {
      public tbltrip GetPrice(string trip);  
      public void Update(tbltrip customer);
      public void Book(tbltrip customer);
      public List<tbltrip> GetAll();
      public void Remove(int id);
    }
}