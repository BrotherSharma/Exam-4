using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using _4th_Exam.Models;
using Npgsql;

namespace _4th_Exam.Repository
{
    public class AdminRepository : IAdminRepository
    {
        public readonly NpgsqlConnection _conn;
        public AdminRepository(NpgsqlConnection conn)
        {
            _conn = conn;
        }
        public List<tbltrip> GetAll()
        {
            var trip = new List<tbltrip>();
            _conn.Open();
            using var command = new NpgsqlCommand("SELECT * FROM t_trip",_conn);
            command.CommandType = CommandType.Text;
            using var reader = command.ExecuteReader();
            while(reader.Read())
            {
                var tbltrip = new tbltrip();
                {
                    tbltrip.c_tripname = reader["c_tripname"].ToString();
                    tbltrip.c_price =Convert.ToInt32(reader["c_price"]);
                    tbltrip.c_stock =Convert.ToInt32(reader["c_stock"]);
                    tbltrip.c_avail =Convert.ToInt32(reader["c_avail"]);
                    tbltrip.c_id =Convert.ToInt32(reader["c_id"]);
                }
                trip.Add(tbltrip);
            }
            _conn.Close();
            return trip;

        }

        public void Insert(tbltrip trip)
        {
            _conn.Open();
            using var command = new NpgsqlCommand("INSERT INTO t_trip (c_tripname, c_price, c_stock, c_avail) VALUES (@c_tripname, @c_price, @c_stock, @c_avail)",_conn);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@c_tripname",trip.c_tripname);
            command.Parameters.AddWithValue("@c_price",trip.c_price);
            command.Parameters.AddWithValue("@c_stock",trip.c_stock);
            command.Parameters.AddWithValue("@c_avail",trip.c_avail);
            command.ExecuteNonQuery();
            _conn.Close();

        }
        public tbltrip GetOne(int id)
        {
            var tbltrip = new tbltrip();
            _conn.Open();
            using var command = new NpgsqlCommand("SELECT * FROM t_trip WHERE c_id = @c_id",_conn);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@c_id",id);
            using var reader = command.ExecuteReader();
            while(reader.Read())
            {
                
                
                    tbltrip.c_tripname = reader["c_tripname"].ToString();
                    tbltrip.c_price =Convert.ToInt32(reader["c_price"]);
                    tbltrip.c_stock =Convert.ToInt32(reader["c_stock"]);
                    tbltrip.c_avail =Convert.ToInt32(reader["c_avail"]);
                    tbltrip.c_id =Convert.ToInt32(reader["c_id"]);
                
            }
            _conn.Close();
            return tbltrip;
        }

        public void Update(tbltrip trip)
        {
            _conn.Open();
            using var command = new NpgsqlCommand("UPDATE t_trip SET c_tripname=@c_tripname,c_price= @c_price,c_stock= @c_stock,c_avail= @c_avail WHERE c_id =@c_id",_conn);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@c_id",trip.c_id);
            command.Parameters.AddWithValue("@c_tripname",trip.c_tripname);
            command.Parameters.AddWithValue("@c_price",trip.c_price);
            command.Parameters.AddWithValue("@c_stock",trip.c_stock);
            command.Parameters.AddWithValue("@c_avail",trip.c_avail);
            command.ExecuteNonQuery();
            _conn.Close();

        }
        public void Delete(int id)
        {
            _conn.Open();
            using var command = new NpgsqlCommand("DELETE FROM t_trip  WHERE c_id =@c_id",_conn);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@c_id",id);
            command.ExecuteNonQuery();
            _conn.Close();
        }        
    }
}