using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using _4th_Exam.Models;
using _4th_Exam.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace _4th_Exam.Controllers
{
    //[Route("[controller]")]
    public class UserController : Controller
    {
        private readonly ILogger<UserController> _logger;
        private readonly IUserRepository _repo;

        public UserController(ILogger<UserController> logger,IUserRepository repo)
        {
            _logger = logger;
            _repo= repo;
        }

        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult GetPrice(string trip)
        {
            var price = _repo.GetPrice(trip);
            return Json(new {price = price.c_price, stock = price.c_stock});
        }
        [HttpPost]
        public IActionResult Update(tbltrip trip)
        {
            _repo.Update(trip);
            _repo.Book(trip);
            return RedirectToAction("Histrory");
        }
        public IActionResult Histrory()
        {
            var history = _repo.GetAll();
            return View(history);
        }
        public IActionResult Remove(int id)
        {
            _repo.Remove(id);
            return RedirectToAction("Histrory");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}