using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using _4th_Exam.Models;
using _4th_Exam.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace _4th_Exam.Controllers
{
    //[Route("[controller]")]
    public class AdminController : Controller
    {
        private readonly ILogger<AdminController> _logger;
        private readonly IAdminRepository _repo;


        public AdminController(ILogger<AdminController> logger, IAdminRepository repo)
        {
            _logger = logger;
            _repo = repo;
        }
        [HttpGet]
        public IActionResult GetAllLink()
        {
             var get =_repo.GetAll();
            return Json(get);
        }
        [HttpGet]
        public IActionResult GetAll()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Insert()
        {
            // _repo.Insert(trip);
            return View();
        }
        [HttpPost]
        public IActionResult Insert(tbltrip trip)
        {
            _repo.Insert(trip);
            return Json(new { success = true});
        }
        // [HttpGet]
        // public IActionResult Update(int id)
        // {
        //     var getone = _repo.GetOne(id);
        //     return View(getone);
        // }
        [HttpPost]
        public IActionResult Update(tbltrip trip)
        {
            _repo.Update(trip);
            return Json(new { success = true });
        }
        public IActionResult Delete(int id)
        {
            _repo.Delete(id);
            return Ok();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}