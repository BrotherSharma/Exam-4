using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using _4th_Exam.Models;
using _4th_Exam.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace _4th_Exam.Controllers
{
    //[Route("[controller]")]
    public class LoginController : Controller
    {
        private readonly ILogger<LoginController> _logger;
        private readonly ILoginRepository _repo;

        public LoginController(ILogger<LoginController> logger,ILoginRepository repo)
        {
            _logger = logger;
            _repo = repo;
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(tbllogin login)
        {
            
            
            bool islogin =_repo.Login(login);
            if(islogin)
            {
                // Console.WriteLine(login.c_role);    
                _logger.LogInformation($"Login successful. Role: {login.c_role}");
                if(login.c_role == "Admin")
                {
                     return RedirectToAction("GetAll","Admin");
                }
                else{
                    return RedirectToAction("Index","User");
                }
                 
            }
            else{
                 return RedirectToAction("Login");
            }
            
           
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}