using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace _4th_Exam.Models
{
    public class tbllogin
    {
        public int c_id{get; set;}
        [Required(ErrorMessage = "Email is required")]

        public string c_email{get; set;}
        [Required(ErrorMessage = "Password is required")]
        public string c_password{get; set;}
        public string c_role{get; set;}
    }
}