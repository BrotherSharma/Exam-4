using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace _4th_Exam.Models
{
    public class tbltrip
    {
        public int c_id{get; set;}
        public string c_tripname{get; set;}
        public int c_price{get; set;}
        public int c_stock{get; set;}
        public int c_avail{get; set;}
        public int c_quantity{get; set;}
        public int c_total{get; set;}
        public string c_status{get; set;}
    }
}